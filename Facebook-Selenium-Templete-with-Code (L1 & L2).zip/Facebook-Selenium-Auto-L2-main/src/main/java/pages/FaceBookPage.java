package pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class FaceBookPage extends StartupPage {
	//please write all the locators for facebook page only 

	//	By loginButton = By.xpath(""); 
	//	By emailAddsPhoneNumberTextbox = By.xpath(""); 
	//	By passwordTextbox = By.xpath(""); 
	//	By profileIconImage = By.xpath(""); 
	//	By logoutButton = By.xpath(""); 
	//	By forgettenPasswordLink = By.xpath(""); 
	//	By createNewAccountLink = By.xpath(""); 
	//	By emailTextField = By.id(""); 
	//	By errorMessageWithoutCredential = By.xpath(""); 
	//	By errorMessageWithoutCredentialForgetPassword = By.xpath(""); 
	//	By withoutPasswordErrorMessage = By.xpath("");
	//
	//	By createNewAccount = By.xpath(""); 
	//	By signUpButton = By.xpath(""); 
	//	By nameFieldErorMessage = By.xpath(""); 
	//	By firstNameTextField = By.xpath(""); 
	//	By surNameTextField = By.xpath(""); 
	//	By mobileNumberAndPassword = By.xpath(""); 
	//	By newPassword = By.xpath(""); 
	//	By selectDateFromDateDropdown = By.xpath(""); 
	//	By selectBirthdayMonth = By.xpath("");
	//	By selectBirthDayYear = By.xpath("");
	//	By customRadioButton = By.xpath("");
	//	By selectYourPronounDropdown = By.xpath("");
	//	By genderOptionalTextBox = By.xpath("");
	//	By selectFemaleRadioButton = By.xpath("");
	//	By selectMaleRadioButton = By.xpath("");
	//	By closeSignupPageImage = By.xpath("");
	//	By profile = By.xpath(""); 
	//	By profileName = By.xpath(""); 
	//	By updateProfilePicture = By.xpath(""); 
	//	By uploadPhoto = By.xpath(""); 
	//	By saveButton = By.xpath(""); 
	//	By editProfileButton=By.xpath("");
	//	By addButtonInsideBioSection=By.xpath("");
	//	By describeWhoAreYouTextField=By.xpath("");
	//	By saveButtonPresentInsideTheBioSection=By.xpath("");
	//	By xButton=By.xpath("");
	//	By addBioButton=By.xpath("");
	//	By aboutSection=By.xpath("");
	//	By workAndEducationSection=By.xpath("");
	//	By addUniversityIcon=By.xpath("");
	//	By schoolTextField=By.xpath("");
	//	By upperArrowButtonToHideTheYouMayKnowSection=By.xpath("");
	//	By addWorkplaceButton=By.xpath("");
	//	By companyTextField=By.xpath("");	
	//	By addCurrentCityButton=By.xpath("");
	//	By currentCityTextField=By.xpath("");
	//	By addHomeTownButton=By.xpath("");
	//	By homeTownTextField=By.xpath("");
	//	By cancelButton=By.xpath("");
	//	By addSecondarySchoolButton=By.xpath("");
	//	By schoolTextFieldPresentInsideSecondarySchoolTextField=By.xpath("");
	//	By addRelationshipStatusButton=By.xpath("");
	//	By stausDropdown=By.xpath("");
	//	By selectSingle=By.xpath("");
	//	By accountIcon=By.xpath("");
	//	By leavePageButton=By.xpath("");
	//	By LogoutButton=By.xpath("");
	//	By updateProfilePictureCameraIcon = By.xpath(""); 
	//	By uploadPhotoButton = By.xpath(""); 
	//	By notificationLink=By.xpath("");
	//	By errorMessageWithoutCredential1 = By.xpath(""); 	
	//	By withoutPasswordErrorMessage1 = By.xpath("");

	By loginButton = By.xpath("//button[@name='login']"); 
	By emailAddsPhoneNumberTextbox = By.xpath("//input[@placeholder='Email address or phone number']"); 
	By passwordTextbox = By.xpath("//input[@placeholder='Password']"); 
	By profileIconImage = By.xpath("(//div//div//span)[14]"); 
	By logoutButton = By.xpath("//span[contains(text (), 'Log out')]"); 
	By forgettenPasswordLink = By.xpath("//a[.='Forgotten password?']"); 
	By createNewAccountLink = By.xpath("//a[contains(text() , 'Create new account')]"); 
	By emailTextField = By.id("email"); 
	By errorMessageWithoutCredential = By.xpath("//div[@id='email_container']//div[2]"); 
	By errorMessageWithoutCredential1 = By.xpath("//div[.='Invalid username or password']"); 
	By errorMessageWithoutCredentialForgetPassword = By.xpath("//div[@id='email_container']//div[2]/a"); 
	By withoutPasswordErrorMessage = By.xpath("//div[contains(@class, 'clearfix') and contains(@class, 'mg')]//div[2]");
	By withoutPasswordErrorMessage1 = By.xpath("//div[.='Invalid username or password']");


	By createNewAccount = By.xpath("//a[contains(text(),'Create new account')]"); 
	By signUpButton = By.xpath("//button[@name=\"websubmit\"]"); 
	By nameFieldErorMessage = By.xpath("//div[@id='js_134']"); 
	By firstNameTextField = By.xpath("//input[@name=\"firstname\"]"); 
	By surNameTextField = By.xpath("//input[@name=\"lastname\"]"); 
	By mobileNumberAndPassword = By.xpath("//input[@name=\"reg_email__\"]"); 
	By newPassword = By.xpath("(//input[@type=\"password\"])[2]"); 
	By selectDateFromDateDropdown = By.xpath("//select[@name='birthday_day']"); 
	By selectBirthdayMonth = By.xpath("//select[@name='birthday_month']");
	By selectBirthDayYear = By.xpath("//select[@name='birthday_year']");
	By customRadioButton = By.xpath("//label[contains(text() , 'Custom')]");
	By selectYourPronounDropdown = By.xpath("//select[@name='preferred_pronoun']");
	By genderOptionalTextBox = By.xpath("//input[@name='custom_gender']");
	By selectFemaleRadioButton = By.xpath("//label[contains(text() , 'Female')]");
	By selectMaleRadioButton = By.xpath("//label[contains(text() , 'Male')]");
	By closeSignupPageImage = By.xpath("//img[contains(@src, '.png')]");

	//	By loginButton = By.xpath("//button[@name='login']"); 
	//	By emailAddsPhoneNumberTextbox = By.xpath("//input[@placeholder='Email address or phone number']"); 
	//	By passwordTextbox = By.xpath("//input[@placeholder='Password']"); 
	//	By createNewAccount = By.xpath("//a[contains(text(),'Create new account')]"); 
	//	By signUpButton = By.xpath("//button[@name=\"websubmit\"]"); 
	//	By nameFieldErorMessage = By.xpath("//div[@id='js_134']"); 
	//	By firstNameTextField = By.xpath("//input[@name=\"firstname\"]"); 
	//	By surNameTextField = By.xpath("//input[@name=\"lastname\"]"); 
	//	By mobileNumberAndPassword = By.xpath("//input[@name=\"reg_email__\"]"); 
	//	By newPassword = By.xpath("(//input[@type=\"password\"])[2]"); 
	By profile = By.xpath("(//span[.='Shibu Dharshan'])[1]"); 
	By profileName = By.xpath("//h1[contains(text(),'Shibu Dharshan')]"); 
	By updateProfilePictureCameraIcon = By.xpath("//div[@aria-label=\"Update profile picture\"]"); 
	By uploadPhotoButton = By.xpath("//span[contains(text(),'Upload Photo')]"); 
	By saveButton = By.xpath("(//span[.='Save'])[1]"); 
	By editProfileButton=By.xpath("//span[contains(text(),'Edit profile')]");
	By addButtonInsideBioSection=By.xpath("(//div[@aria-label=\"Add Bio\"])[2]");
	By describeWhoAreYouTextField=By.xpath("//textarea[@aria-label=\"Enter bio text\"]");
	By saveButtonPresentInsideTheBioSection=By.xpath("(//span[.='Save'])[2]");
	By xButton=By.xpath("//div[contains(@class,'x92rtbv x10l6tqk x1tk7jg1 x1vjfeg')]");
	By addBioButton=By.xpath("(//span[.='Add Bio'])[2]");
	By aboutSection=By.xpath("//span[.='About']");
	By workAndEducationSection=By.xpath("//span[.='Work and education']");
	By addUniversityIcon=By.xpath("//span[contains(text(),'Add university')]");
	By schoolTextField=By.xpath("//input[@aria-label=\"School\"]");
	By upperArrowButtonToHideTheYouMayKnowSection=By.xpath("//div[@data-pagelet='ProfileActions']//i");
	By addWorkplaceButton=By.xpath("//span[contains(text(),'Add a workplace')]");
	By companyTextField=By.xpath("//input[@aria-label=\"Company\"]");	
	By addCurrentCityButton=By.xpath("//span[.='Add current city']");
	By currentCityTextField=By.xpath("//input[@aria-label=\"Current town/city\"]");
	By addHomeTownButton=By.xpath("//span[.='Add home town']");
	By homeTownTextField=By.xpath("//input[@aria-label=\"Home town\"]");
	By cancelButton=By.xpath("(//div[@aria-label=\"Cancel\"])[1]");
	By addSecondarySchoolButton=By.xpath("//span[.='Add secondary school']");
	By schoolTextFieldPresentInsideSecondarySchoolTextField=By.xpath("//input[@aria-label=\"School\"]");
	By addRelationshipStatusButton=By.xpath("//span[.='Add a relationship status']");
	By stausDropdown=By.xpath("//span[contains(text(),'Status')]");
	By selectSingle=By.xpath("//span[contains(text(),'Single')]");
	By accountIcon=By.xpath("(//div[contains(@class,\"x1rg5ohu x1n2onr6 x3ajldb x1ja2u2z\")])[1]");
	By leavePageButton=By.xpath("(//span[.='Leave Page'])[3]");
	By LogoutButton=By.xpath("//span[contains(text(),'Log out')]");
	By notificationLink=By.xpath("//div[@class=\"x6s0dn4 x78zum5 x5yr21d xl56j7k x1emribx\"]//a[contains(@aria-label,\"Notifications\")]");





	public FaceBookPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this); // Initialize Page Factory
		// TODO Auto-generated constructor stub
	}


	/** @test1
	 * about this method validateFacebookTitleOfLoginPage() 
	 * @param : null
	 * @description : it is getting the page title and return the same,
	 * @return : title of string type
	 * @author : Yaksha
	 */
	public String validateFacebookTitleOfLoginPage() throws Exception {
		String currentPageTitle="";
		try {
			currentPageTitle= commonEvents.getTitle();
			System.out.println("Title of the Login Page : " + currentPageTitle );
		}catch(Exception e) {
			throw e;
		}
		return currentPageTitle;

	}


	//	/** @test1
	//	 * about this method validateFacebookTitleOfLoginPage() 
	//	 * @param : null
	//	 * @description : it is getting the page title and return the same,
	//	 * @return : title of string type
	//	 * @author : Yaksha
	//	 */
	//	public String validateFacebookTitleOfLoginPage() throws Exception {
	//		return null;
	//
	//	}

	//	/**@test2
	//	 * about this method verifyPresenceOfALlFields() 
	//	 * @param : null
	//	 * @description : it is verify all fields is present in current page or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean verifyPresenceOfALlFields() throws Exception {
	//		return null;
	//	}

	/**@test2
	 * about this method verifyPresenceOfALlFields() 
	 * @param : null
	 * @description : it is verify all fields is present in current page or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean verifyPresenceOfALlFields() throws Exception {
		Boolean createNewAccountLinkIsDisplayed=false;
		try {
			if(commonEvents.isDisplayed(emailAddsPhoneNumberTextbox)&&
					commonEvents.isDisplayed(passwordTextbox)) {

				WebElement emailPhoneNumberTextbox = commonEvents.findElement(emailAddsPhoneNumberTextbox);
				commonEvents.highlightElement(emailPhoneNumberTextbox);

				WebElement passwordTextboxWebelement = commonEvents.findElement(passwordTextbox);
				commonEvents.highlightElement(passwordTextboxWebelement);

				createNewAccountLinkIsDisplayed= true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return createNewAccountLinkIsDisplayed;
	}

	//	/**@test3
	//	 * about this method validateErrorMessageWithoutProvideAnyCredentials() 
	//	 * @param : null
	//	 * @description : it is getting the error message if login button clicked without passing email and password
	//	 * @return : errorMessage as string type
	//	 * @author : Yaksha
	//	 */
	//	public String validateErrorMessageWithoutProvideAnyCredentials() throws Exception {
	//		return null;
	//	}

	/**@test3
	 * about this method validateErrorMessageWithoutProvideAnyCredentials() 
	 * @param : null
	 * @description : it is getting the error message if login button clicked without passing email and password
	 * @return : errorMessage as string type
	 * @author : Yaksha
	 */
	public String validateErrorMessageWithoutProvideAnyCredentials() throws Exception {
		String errorMessageWithoutCredentials="";
		String errorMessage="";
		commonEvents.click(loginButton);
		commonEvents.waitTillElementLocated(emailTextField, 60);

		try {
			if(commonEvents.isDisplayed(errorMessageWithoutCredential))
			{
				errorMessageWithoutCredentials =  commonEvents.getText(errorMessageWithoutCredential);
				System.out.println("Error message is :" +errorMessageWithoutCredentials);
				return errorMessageWithoutCredentials;
			}
			else 
			{
				errorMessage=commonEvents.getText(errorMessageWithoutCredential1);
				System.out.println("Error message is :" +errorMessage);
				return errorMessage;
			}

		}catch(Exception e) {
			System.out.println("No element found");
			throw e;
		}
	}

	//	/**@test4.1
	//	 * about this method enterEmailIdOrPhoneNumberInLoginPage() 
	//	 * @param : Map<String, String> expectedData
	//	 * @description : enter EmailIdOrPhoneNumber in the EmailIdOrPhoneNumber text field of the login page as per json expected data ,
	//	 * @return : null
	//	 * @author : Yaksha
	//	 */
	//	public boolean enterEmailIdOrPhoneNumberInLoginPage(Map<String, String> expectedData) throws Exception {
	//		return false;
	//	}

	/**@test4.1
	 * about this method enterEmailIdOrPhoneNumberInLoginPage() 
	 * @param : Map<String, String> expectedData
	 * @description : enter EmailIdOrPhoneNumber in the EmailIdOrPhoneNumber text field of the login page as per json expected data ,
	 * @return : null
	 * @author : Yaksha
	 */
	public boolean enterEmailIdOrPhoneNumberInLoginPage(Map<String, String> expectedData) throws Exception {
		Boolean emailTextFieldIsDisplayed=false;
		try {
			if(commonEvents.isDisplayed(emailTextField))
			{
				commonEvents.sendKeys(emailTextField,expectedData.get("emailAddsPhoneNumber"));
				emailTextFieldIsDisplayed= true;
			}
		}catch(Exception e) {
			throw e;
		}
		return emailTextFieldIsDisplayed;
	}

	//	/**@test4.2
	//	 * about this method validateErrorMessageWithoutProvidePassword() 
	//	 * @param : null
	//	 * @description : it is getting the error message and validate the error message ,
	//	 * @return : errorMessage as string type
	//	 * @author : Yaksha
	//	 */
	//	public String validateErrorMessageWithoutProvidePassword(Map<String, String> expectedData) throws Exception {
	//		return null;
	//	}

	/**@test4.2
	 * about this method validateErrorMessageWithoutProvidePassword() 
	 * @param : null
	 * @description : it is getting the error message and validate the error message ,
	 * @return : errorMessage as string type
	 * @author : Yaksha
	 */
	public String validateErrorMessageWithoutProvidePassword(Map<String, String> expectedData) throws Exception {
		String errorMessageWithoutPassword="";
		String errorMessage="";
		try {
			commonEvents.click(loginButton);
			commonEvents.waitTillElementLocated(passwordTextbox, 60);
			if(commonEvents.isDisplayed(withoutPasswordErrorMessage))
			{
				errorMessageWithoutPassword =  commonEvents.getText(withoutPasswordErrorMessage);
				//			System.out.println("Error Message : " + errorMessageWithoutPassword);
				return errorMessageWithoutPassword;
			}
			else
			{
				errorMessage=commonEvents.getText(withoutPasswordErrorMessage1);
				System.out.println("Error message is :" +errorMessage);
				return errorMessage;
			}
		}catch(Exception e) {
			throw e;
		}
	}

	//	/**@test5.1
	//	 * about this method enterPassword() 
	//	 * @param : Map<String, String> expectedData
	//	 * @description : enter password in the password text field of the login page as per json expected data ,
	//	 * @return : null
	//	 * @author : Yaksha
	//	 */
	//	public boolean enterPasswordInLoginPage(Map<String, String> expectedData) throws Exception {
	//		return false;
	//	}

	/**@test5.1
	 * about this method enterPassword() 
	 * @param : Map<String, String> expectedData
	 * @description : enter password in the password text field of the login page as per json expected data ,
	 * @return : null
	 * @author : Yaksha
	 */
	public boolean enterPasswordInLoginPage(Map<String, String> expectedData) throws Exception {
		Boolean passwordTextboxisFilled=false;
		try {
			commonEvents.clear(emailAddsPhoneNumberTextbox);
			commonEvents.sendKeys(passwordTextbox,expectedData.get("password"));
			if(commonEvents.getAttribute(passwordTextbox, "value").equals(expectedData.get("password"))) {
				passwordTextboxisFilled = true;
			}

		}catch(Exception e) {
			throw e;
		}
		return passwordTextboxisFilled;
	}

	//	/**@test5.2
	//	 * about this method validateErrorMessageWithoutProvideEmailOrPhoneNumber() 
	//	 * @param : null
	//	 * @description : it is getting the error message and validate the error message ,
	//	 * @return : errorMessage as string type
	//	 * @author : Yaksha
	//	 */
	//	public String validateErrorMessageWithoutProvideEmailOrPhoneNumber() throws Exception {
	//		return null;
	//	}

	/**@test5.2
	 * about this method validateErrorMessageWithoutProvideEmailOrPhoneNumber() 
	 * @param : null
	 * @description : it is getting the error message and validate the error message ,
	 * @return : errorMessage as string type
	 * @author : Yaksha
	 */
	public String validateErrorMessageWithoutProvideEmailOrPhoneNumber() throws Exception {
		String errorMessageWithoutCredentials="";
		String errorMessage="";
		try {
			commonEvents.click(loginButton);
			commonEvents.waitTillElementLocated(emailTextField, 60);
			if(commonEvents.isDisplayed(errorMessageWithoutCredential))
			{
				errorMessageWithoutCredentials =  commonEvents.getText(errorMessageWithoutCredential);
				System.out.println("Error message is:"+errorMessageWithoutCredentials);
				return errorMessageWithoutCredentials ;
			}
			else
			{
				errorMessage =  commonEvents.getText(errorMessageWithoutCredential1);
				System.out.println("Error message is:"+errorMessageWithoutCredentials);
				return errorMessage;
			}
		}catch(Exception e) {
			throw e;
		}
	}

	//	/**@test6
	//	 * about this method goBackToLogInPageAndValidateCreateNewAccountButtonIsPresentOrNot() 
	//	 * @param : null
	//	 * @description : here go back to the login page and verify whether the NewAccountButton element is present or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean goBackToLogInPageAndValidateCreateNewAccountButtonIsPresentOrNot() throws Exception {
	//		return null;
	//	}

	/**@test6
	 * about this method goBackToLogInPageAndValidateCreateNewAccountButtonIsPresentOrNot() 
	 * @param : null
	 * @description : here go back to the login page and verify whether the NewAccountButton element is present or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean goBackToLogInPageAndValidateCreateNewAccountButtonIsPresentOrNot() throws Exception {
		Boolean createNewAccountIsDisplayed=false;
		try {
			commonEvents.navigateBack();		
			driver.get("https://www.facebook.com/");
			Thread.sleep(5000);
			commonEvents.waitTillElementLocated(createNewAccount, 60);
			if(commonEvents.isDisplayed(createNewAccount)) {
				createNewAccountIsDisplayed=true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return createNewAccountIsDisplayed;
	}

	//	/**@test7
	//	 * about this method validateNavigateToTheSignUpPage() 
	//	 * @param : null
	//	 * @description : click on the createnew account and validate the sign up page title ,
	//	 * @return : title of string type
	//	 * @author : Yaksha
	//	 */
	//	public String validateNavigateToTheSignUpPage() throws Exception {
	//		return null;
	//
	//	}

	/**@test7
	 * about this method validateNavigateToTheSignUpPage() 
	 * @param : null
	 * @description : click on the createnew account and validate the sign up page title ,
	 * @return : title of string type
	 * @author : Yaksha
	 */
	public String validateNavigateToTheSignUpPage() throws Exception {
		String signUpPageTitle="";
		try {
			commonEvents.click(createNewAccount);
			commonEvents.waitTillElementLocated(createNewAccount, 60);
			signUpPageTitle	=  driver.getTitle();
			System.out.println("Title of the Signup Page : " + signUpPageTitle );

		}catch(Exception e) {
			throw e;
		}
		return signUpPageTitle;

	}

	//	/**@test8
	//	 * about this method verifyPresenceOfAllFieldsPresentInTheSignUpPage() 
	//	 * @param : null
	//	 * @description : verify all fields are present in the signup page or not ,
	//	 * @return : boolean
	//	 * @author : Yaksha
	//	 */
	//	public Boolean verifyPresenceOfAllFieldsPresentInTheSignUpPage() throws Exception {
	//		return null;
	//	}

	/**@test8
	 * about this method verifyPresenceOfAllFieldsPresentInTheSignUpPage() 
	 * @param : null
	 * @description : verify all fields are present in the signup page or not ,
	 * @return : boolean
	 * @author : Yaksha
	 */
	public Boolean verifyPresenceOfAllFieldsPresentInTheSignUpPage() throws Exception {
		Boolean newPasswordIsDisplayed=false;
		try {
			if(commonEvents.isDisplayed(firstNameTextField)&&
					commonEvents.isDisplayed(surNameTextField)&&
					commonEvents.isDisplayed(mobileNumberAndPassword)&&
					commonEvents.isDisplayed(newPassword)) {
				newPasswordIsDisplayed= true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return newPasswordIsDisplayed;
	}

	//	/**@test9
	//	 * about this method enterDataInFirstNameFieldSignupPage() 
	//	 * @param : Map<String, String>
	//	 * @description : Enter data in the first name text field of the Signup page,
	//	 * @return : String
	//	 * @author : Yaksha
	//	 */
	//	public  String enterDataInFirstNameFieldSignupPage( Map<String, String> expectedData) throws Exception {
	//		return null;
	//	}

	/**@test9
	 * about this method enterDataInFirstNameFieldSignupPage() 
	 * @param : Map<String, String>
	 * @description : Enter data in the first name text field of the Signup page,
	 * @return : String
	 * @author : Yaksha
	 */
	public  String enterDataInFirstNameFieldSignupPage( Map<String, String> expectedData) throws Exception {
		String firstNameTextFieldString="";
		try {
			commonEvents.sendKeys(firstNameTextField,expectedData.get("FirstName"));
			firstNameTextFieldString=commonEvents.getText(firstNameTextField);
			System.out.println(firstNameTextFieldString);
		}catch(Exception e) {
			throw e;
		}
		return firstNameTextFieldString;
	}

	//	/**@test10
	//	 * about this method enterDataInSignUpPage() 
	//	 * @param : Map<String, String>
	//	 * @description : enter data in the  SignUpPage page,
	//	 * @return : null
	//	 * @author : Yaksha
	//	 *
	//	 */
	//	public  boolean enterDataInSignUpPage( Map<String, String> expectedData) throws Exception {
	//		return false;
	//	}

	/**@test10
	 * about this method enterDataInSignUpPage() 
	 * @param : Map<String, String>
	 * @description : enter data in the  SignUpPage page,
	 * @return : null
	 * @author : Yaksha
	 *
	 */
	public  boolean enterDataInSignUpPage( Map<String, String> expectedData) throws Exception {
		Boolean newPasswordIsFilled=false;
		try {
			commonEvents.sendKeys(surNameTextField,expectedData.get("surname"));
			commonEvents.sendKeys(mobileNumberAndPassword,expectedData.get("emailOrMobileNumber"));
			commonEvents.sendKeys(newPassword,expectedData.get("newPassword"));
			if(commonEvents.getAttribute(newPassword, "value").equals(expectedData.get("newPassword"))) {
				newPasswordIsFilled = true;
			}

		}catch(Exception e) {
			throw e;
		}
		return newPasswordIsFilled;
	}

	//	/**@test11
	//	 * about this method selectDateFromDateDropdownAndVerifyDateDropdownIsPrsentOrNot() 
	//	 * @param : null
	//	 * @description : it is select any date from date dropdown and verify Date Dropdown is present in current page or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean selectDateFromDateDropdownAndVerifyDateDropdownIsPrsentOrNot() throws Exception {
	//		return null;
	//	}

	/**@test11
	 * about this method selectDateFromDateDropdownAndVerifyDateDropdownIsPrsentOrNot() 
	 * @param : null
	 * @description : it is select any date from date dropdown and verify Date Dropdown is present in current page or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean selectDateFromDateDropdownAndVerifyDateDropdownIsPrsentOrNot() throws Exception {
		Boolean selectDateFromDateDropdownIsDisplayed=false;
		commonEvents.selectByValue(selectDateFromDateDropdown, "25");
		try {
			if(commonEvents.isDisplayed(selectDateFromDateDropdown)) {
				selectDateFromDateDropdownIsDisplayed=true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return selectDateFromDateDropdownIsDisplayed;
	}

	//	/**@test12
	//	 * about this method selectAnyMonthFromMonthDropdownAndVerifyMonthDropdownIsPrsentOrNot() 
	//	 * @param : null
	//	 * @description : it is select any month from month dropdown and verify month Dropdown is present in current page or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean selectAnyMonthFromMonthDropdownAndVerifyMonthDropdownIsPrsentOrNot() throws Exception {
	//		return null;
	//	}

	/**@test12
	 * about this method selectAnyMonthFromMonthDropdownAndVerifyMonthDropdownIsPrsentOrNot() 
	 * @param : null
	 * @description : it is select any month from month dropdown and verify month Dropdown is present in current page or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean selectAnyMonthFromMonthDropdownAndVerifyMonthDropdownIsPrsentOrNot() throws Exception {
		Boolean selectBirthdayMonthIsDisplayed=false;
		commonEvents.selectByValue(selectBirthdayMonth, "Jun");
		try {
			if(commonEvents.isDisplayed(selectBirthdayMonth)) {
				selectBirthdayMonthIsDisplayed= true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return selectBirthdayMonthIsDisplayed;
	}

	//	/**@test13
	//	 * about this method selectAnyYearFromYearDropdownAndVerifyYearDropdownIsPrsentOrNot() 
	//	 * @param : null
	//	 * @description : it is select any Year from Year dropdown and verify Year Dropdown is present in current page or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean selectAnyYearFromYearDropdownAndVerifyYearDropdownIsPrsentOrNot() throws Exception {
	//		return null;
	//	}

	/**@test13
	 * about this method selectAnyYearFromYearDropdownAndVerifyYearDropdownIsPrsentOrNot() 
	 * @param : null
	 * @description : it is select any Year from Year dropdown and verify Year Dropdown is present in current page or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean selectAnyYearFromYearDropdownAndVerifyYearDropdownIsPrsentOrNot() throws Exception {
		Boolean selectBirthDayYearIsDisplayed=false;
		commonEvents.selectByValue(selectBirthDayYear, "1996");
		try {
			if(commonEvents.isDisplayed(selectBirthDayYear)) {
				selectBirthDayYearIsDisplayed= true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return selectBirthDayYearIsDisplayed;
	}


	//	/**@test14
	//	 * about this method verifyAllpresentOfFieldAfterCloseTheSignupPage() 
	//	 * @param : null
	//	 * @description : close the sign up page and verify all fields is present in current page or not 
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean verifyAllpresentOfFieldAfterCloseTheSignupPage() throws Exception {
	//		return null;
	//	}

	/**@test14
	 * about this method verifyAllpresentOfFieldAfterCloseTheSignupPage() 
	 * @param : null
	 * @description : close the sign up page and verify all fields is present in current page or not 
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean verifyAllpresentOfFieldAfterCloseTheSignupPage() throws Exception {
		Boolean createNewAccountLinkIsDisplayed=false;
		commonEvents.click(closeSignupPageImage);
		try {
			if(commonEvents.isDisplayed(emailAddsPhoneNumberTextbox)&&
					commonEvents.isDisplayed(passwordTextbox)&&
					commonEvents.isDisplayed(forgettenPasswordLink)&&
					commonEvents.isDisplayed(createNewAccountLink)) {
				createNewAccountLinkIsDisplayed=true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return createNewAccountLinkIsDisplayed;
	}

	//	/**@test15
	//	 * about this method enterValidEmail_PasswordInTextFieldAndVerifyLoginButtonIsPresentOrNot() 
	//	 * @param : Map<String, String> expectedData (getting the data from the expected Json file
	//	 * @description : enter the username and password in the corresponding Text filed and verify login button is present or not
	//	 * @return : true
	//	 * @author : Yaksha
	//	 */
	//	public Boolean enterValidEmail_PasswordInTextFieldAndVerifyLoginButtonIsPresentOrNot(Map<String, String> expectedData) throws Exception {
	//		return null;
	//	}

	/**@test15
	 * about this method enterValidEmail_PasswordInTextFieldAndVerifyLoginButtonIsPresentOrNot() 
	 * @param : Map<String, String> expectedData (getting the data from the expected Json file
	 * @description : enter the username and password in the corresponding Text filed and verify login button is present or not
	 * @return : true
	 * @author : Yaksha
	 */
	public Boolean enterValidEmail_PasswordInTextFieldAndVerifyLoginButtonIsPresentOrNot(Map<String, String> expectedData) throws Exception {
		Boolean loginButtonIsDisplay=false;
		commonEvents.sendKeys(emailAddsPhoneNumberTextbox,expectedData.get("Username"));
		commonEvents.sendKeys(passwordTextbox,expectedData.get("Password"));
		try {
			if(commonEvents.isDisplayed(loginButton)) {
				loginButtonIsDisplay= true;
			}	
		}catch(Exception e) {
			throw e;	
		}
		return loginButtonIsDisplay;
	}

	///**@Test16
	//	 * about this method loginToFacebookByGivenValidCredential() 
	//	 * @param : Map<String, String>
	//	 * @description : fill emailAddsPhoneNumberTextbox then enter data in passwordTextbox and click on login button
	//	 * @return : Boolean
	//	 * @author : Yaksha
	//	 */
	//	public boolean loginToFacebookByGivenValidCredential(Map<String, String> expectedData) throws Exception {
	//		return false;
	//	}
	/**@Test16
	 * about this method loginToFacebookByGivenValidCredential() 
	 * @param : Map<String, String>
	 * @description : fill emailAddsPhoneNumberTextbox then enter data in passwordTextbox and click on login button
	 * @return : Boolean
	 * @author : Yaksha
	 */
	public boolean loginToFacebookByGivenValidCredential(Map<String, String> expectedData) throws Exception {
		Boolean profileIsDisplayed=false;
		try {
			commonEvents.sendKeys(emailAddsPhoneNumberTextbox,expectedData.get("phoneNumberAsUsername"));	
			commonEvents.sendKeys(passwordTextbox,expectedData.get("password1"));
			commonEvents.click(loginButton);
			if(commonEvents.isDisplayed(profile))
			{
				profileIsDisplayed=true;
			}
		}catch(Exception e) {
			throw e;
		}
		return profileIsDisplayed;
	}

	//	/**@Test17
	//	 * about this method afterLoggedinValidateTheTitleOfFacebookHomePage() 
	//	 * @param : null
	//	 * @description : print the title of the home page after logged in and verify the title of the home page
	//	 * @return : String
	//	 * @author : Yaksha
	//	 */
	//	public String afterLoggedinValidateTheTitleOfFacebookHomePage() throws Exception {
	//		return null;
	//	}
	/**@Test17
	 * about this method afterLoggedinValidateTheTitleOfFacebookHomePage() 
	 * @param : null
	 * @description : print the title of the home page after logged in and verify the title of the home page
	 * @return : String
	 * @author : Yaksha
	 */
	public String afterLoggedinValidateTheTitleOfFacebookHomePage() throws Exception {
		String currentPageTitle="";
		try {
			commonEvents.click(notificationLink);
			commonEvents.click(notificationLink);
			currentPageTitle	=  driver.getTitle();
			System.out.println("Title of the Home Page after logged in:" + currentPageTitle );
		}catch(Exception e) {
			throw e;
		}
		return currentPageTitle;
	}

	//	/**@Test18
	//	 * about this method clickonProfileIconAndValidateTheProfileName() 
	//	 * @param : null
	//	 * @description :click on the profile and validate the profile name
	//	 * @return : String
	//	 * @author : Yaksha
	//	 */
	//	public String clickonProfileAndValidateTheProfileName() throws Exception {
	//		return null;
	//	}
	/**@Test18
	 * about this method clickonProfileIconAndValidateTheProfileName() 
	 * @param : null
	 * @description :click on the profile and validate the profile name
	 * @return : String
	 * @author : Yaksha
	 */
	public String clickonProfileAndValidateTheProfileName() throws Exception {
		String profilename="";
		try {
			commonEvents.click(profile);
			profilename=commonEvents.getText(profileName);
			System.out.println("Profile name is :"+profilename);
		}catch(Exception e) {
			throw e;
		}
		return profilename;
	}


	//	/**@Test19
	//	 * about this method clickOnUpdateProfilePicture_and_UploadProfilePicture() 
	//	 * @param : String
	//	 * @description :click on update profile picture and click on upload photo and upload photo then click on save button.
	//	 * @return : boolean
	//	 * @author : Yaksha
	//	 */
	//	public boolean clickOnUpdateProfilePictureAndUploadProfilePicture(String filePath) throws Exception {
	//		return false;
	//	}
	/**@Test19
	 * about this method clickOnUpdateProfilePicture_and_UploadProfilePicture() 
	 * @param : String
	 * @description :click on update profile picture and click on upload photo and upload photo then click on save button
	 * @return : boolean
	 * @author : Yaksha
	 */
	public boolean clickOnUpdateProfilePictureAndUploadProfilePicture(String pathOfTheFile) throws Exception {
		boolean isUploaded = false;
		try {
			Thread.sleep(5000);
			commonEvents.jsClick(updateProfilePictureCameraIcon);
			commonEvents.click(uploadPhotoButton);
			System.out.println("path of the file" + pathOfTheFile );
			Thread.sleep(5000);
			commonEvents.fileUpload(pathOfTheFile);
			commonEvents.click(saveButton);
			Thread.sleep(3000);
			isUploaded=true;
		}catch(Exception e) {
			throw e;
		}
		return isUploaded;
	}



	//	/**@Test20
	//	 * about this method gotoThePreviousPageAndClickOnAccount() 
	//	 * @param : null
	//	 * @description : going to the previous page then click on leave page button and click on Account icon which is present at the top right corner
	//	 * @return : boolean
	//	 * @author : Yaksha
	//	 */
	//	public boolean gotoThePreviousPageAndClickOnAccount() throws Exception {
	//		return false;
	//	}
	/**@Test20
	 * about this method gotoThePreviousPageAndClickOnAccount() 
	 * @param : null
	 * @description : going to the previous page then click on leave page button and click on Account icon which is present at the top right corner
	 * @return : boolean
	 * @author : Yaksha
	 */
	public boolean gotoThePreviousPageAndClickOnAccount() throws Exception {
		Boolean accountIconIsDisplayed=false;
		try {
			driver.navigate().back();
			commonEvents.click(leavePageButton);
			commonEvents.jsClick(accountIcon);
			if(commonEvents.isDisplayed(accountIcon))
			{
				accountIconIsDisplayed=true;
			}
		}catch(Exception e) {
			throw e;
		}
		return accountIconIsDisplayed;
	}


	//	/**@Test21
	//	 * about this method clickOnTheLogoutButton() 
	//	 * @param : null
	//	 * @description : Click on the logout button 
	//	 * @return : boolean
	//	 * @author : Yaksha
	//	 */
	//	public boolean clickonTheLogoutButton() throws Exception {
	//		return false;
	//	}
	/**@Test20
	 * about this method clickOnTheLogoutButton() 
	 * @param : null
	 * @description : Click on the logout button 
	 * @return : boolean
	 * @author : Yaksha
	 */
	public boolean clickonTheLogoutButton() throws Exception {
		Boolean emailAddsPhoneNumberTextboxIsDisplayed=false;
		try {
			commonEvents.isDisplayed(LogoutButton);
			commonEvents.click(LogoutButton);
			if(commonEvents.isDisplayed(emailAddsPhoneNumberTextbox))
			{
				emailAddsPhoneNumberTextboxIsDisplayed=true;
			}
		}catch(Exception e) {
			throw e;
		}
		return emailAddsPhoneNumberTextboxIsDisplayed;
	}
}
